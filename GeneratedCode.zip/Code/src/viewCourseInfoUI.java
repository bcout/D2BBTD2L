
/**
 * 
 */

//import static CourseInfoObject.*;

/** 
* <!-- begin-UML-doc -->
* <!-- end-UML-doc -->
* @author bcouturi
* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
*/
public class viewCourseInfoUI {
	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	private viewCourseInfoControl class10;

	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @param courseInfo
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public void displayCourseInfo(CourseInfoObject... courseInfo) {
		// begin-user-code
		// TODO Auto-generated method stub

		// end-user-code
	}

	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public void selectCourseInfoItem() {
		// begin-user-code
		// TODO Auto-generated method stub

		// end-user-code
	}

	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @param selectedItem
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public void displayCourseInfoItem(int selectedItem) {
		// begin-user-code
		// TODO Auto-generated method stub

		// end-user-code
	}
}