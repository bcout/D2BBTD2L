package scole4;

public class PostAssignmentMain {
	
	public static void main(String[] args) {
		DataManager dm = new DataManager();
		PostAssignmentControl control = new PostAssignmentControl(dm);
		PostAssignmentUI ui = new PostAssignmentUI(control);
		
		/// home1/ugrads/scole4/Downloads/Untitled.pdf
		ui.displayPostAssignmentForm();
	}
}
