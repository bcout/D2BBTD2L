package scole4;

import java.sql.Blob;
import java.sql.Date;
import java.util.Set;


public class Assignment {

	public int assignmentId;

	public String assingnmentName;

	public Blob assignmentFile;

	public Date dueDate;

	//public Set<AssignmentSubmission> assignmentSubmission;

	public int courseOfferingId;

	//public Account account;

	public Assignment() {
		
	}
	
}