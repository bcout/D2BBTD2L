package scole4;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.sql.SQLException;
import java.util.Scanner;

import com.oracle.tools.packager.IOUtils;


public class ViewAssignmentUI {


	private ViewAssignmentControl control;
	
	public ViewAssignmentUI(ViewAssignmentControl control) {
		this.control = control;
	}
	
	public void chooseAssignmentassignmentId() {
		// begin-user-code
		// TODO Auto-generated method stub

		// end-user-code
	}


	public void displayAssignmentSelectionForm() {
		 System.out.println("Enter the AssignementID");
		 
		 Scanner scanner = new Scanner(System.in);
         int assignmentID = Integer.parseInt(scanner.next());
         scanner.close();

         Assignment assignment = control.retrieveAssignmentFile(assignmentID);
         
         try {
        	 downloadFile(assignment);
         }catch(SQLException e) {
        	 e.printStackTrace();
         }
         
         System.out.println("wow");
	}
	
	
	public void downloadFile(Assignment assignment) throws SQLException {
		
		try {
			InputStream is = assignment.assignmentFile.getBinaryStream();
			ReadableByteChannel rbc = Channels.newChannel(is);
			FileOutputStream fos = new FileOutputStream("C:\\Downloads"+ "\\" + assignment.assingnmentName);
			fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
			fos.close();
			rbc.close();		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void displayAssignmentWindow() {
		// begin-user-code
		// TODO Auto-generated method stub

		// end-user-code
	}


	public void downloadFile() {
		// begin-user-code
		// TODO Auto-generated method stub

		// end-user-code
	}


	public void uploadFileToClientSystemassignmentObject() {
		// begin-user-code
		// TODO Auto-generated method stub

		// end-user-code
	}
}