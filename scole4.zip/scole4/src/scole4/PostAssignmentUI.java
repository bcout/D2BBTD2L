package scole4;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class PostAssignmentUI {
	
	private PostAssignmentControl control;
	
	public PostAssignmentUI(PostAssignmentControl control) {
		this.control = control;
	}
	
	public void displayPostAssignmentForm() {
		
		System.out.println("Enter the file path");
		 
		Scanner scanner = new Scanner(System.in);
	    String filePath = scanner.next();
	    
	    System.out.println("Enter the assignment name");
	    String assName = scanner.next();
	    
	    System.out.println("Enter the due date");
	    String dueDateIn = scanner.next();
	    
	    scanner.close();
	    
	    control.postAssignment(assName, filePath, dueDateIn);
	    
	}


}
