package scole4;

public class ViewAssignmentMain {
	public static void main(String[] args) {
		DataManager dm = new DataManager();
		ViewAssignmentControl control = new ViewAssignmentControl(dm);
		ViewAssignmentUI ui = new ViewAssignmentUI(control);
		
		ui.displayAssignmentSelectionForm();
	}
}
