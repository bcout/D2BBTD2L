package scole4;

import java.io.File;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.HPos;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class UITestView extends Application {
	
	private Scene postScene;
	private FlowPane postPane;
	private Button submitBtn;
	private Button btnExit;
	private TextField filePath;
	private FileChooser pick;
	private DatePicker date;
	private Stage primaryStage;
	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		this.primaryStage = primaryStage;
		initPostAssignment();
	
		primaryStage.setResizable(false);
		primaryStage.setScene(postScene);
		primaryStage.show();
		
	}
	
	public void displayPostAssignmentForm() { 
		initPostAssignment();
		
	}
	
	public void loadPostAssignmentScene() {
		btnExit = new Button("Exit");
		submitBtn = new Button("Download");
		filePath = new TextField("Enter AssignmentID");
		date = new DatePicker();
		pick = new FileChooser();
		
		postPane= new FlowPane(Orientation.VERTICAL);
		
		File retFile;
		
		
		btnExit.setOnAction(this::processExitButtonPress);
	}
	
	
	public void processExitButtonPress(ActionEvent Event) {
		primaryStage.close();
	}
	
	public void initPostAssignment() {
		loadPostAssignmentScene();
		
		postPane.getChildren().add(btnExit);
		postPane.getChildren().add(filePath);
		
		postPane.getChildren().add(submitBtn);
		
		postPane.setVgap(10);
		postPane.setAlignment(Pos.CENTER);
		postPane.setColumnHalignment(HPos.CENTER); 
        postPane.setRowValignment(VPos.CENTER); 
        postPane.setStyle("-fx-background-color: yellow;");
        
        
        
		postScene = new Scene(postPane, 900, 600);
		
	}
	
}
